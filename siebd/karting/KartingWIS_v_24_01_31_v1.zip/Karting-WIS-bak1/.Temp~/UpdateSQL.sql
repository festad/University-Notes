-- ReviewScoreRange [ent36]
create table `reviewscorerange` (
   `oid`  integer  not null,
   `lowerboundincluded`  double precision,
   `upperboundexcluded`  double precision,
  primary key (`oid`)
);


-- ReviewScoreRange_Track [rel16]
create view `reviewscorerangetotrack_view` as
select AL1.`oid` as `s_oid`, AL2.`oid` as `t_oid`
from  `reviewscorerange` AL1 ,
         `track_2` AL2 
               left outer join `track_avgreviewscore_view` AL3 on AL2.`oid`=AL3.`oid`
where AL1.`lowerboundincluded` <= AL3.`der_attr` AND AL1.`upperboundexcluded` > AL3.`der_attr`;


-- ReviewScoreRange_KartingCenter [rel17]
create view `reviewscorerangetokartingcente` as
select AL1.`oid` as `s_oid`, AL2.`oid` as `t_oid`
from  `reviewscorerange` AL1 ,
         `kartingcenter_2` AL2 
               left outer join `kartingcenter_avgreviewscore_v` AL3 on AL2.`oid`=AL3.`oid`
where AL1.`lowerboundincluded` <= AL3.`der_attr` AND AL1.`upperboundexcluded` > AL3.`der_attr`;


-- ReviewScoreRange_Event [rel39]
create view `reviewscorerangetoevent_view` as
select AL1.`oid` as `s_oid`, AL2.`oid` as `t_oid`
from  `reviewscorerange` AL1 ,
         `event_2` AL2 
               left outer join `event_avgreviewscore_view` AL3 on AL2.`oid`=AL3.`oid`
where AL1.`lowerboundincluded` <= AL3.`der_attr` AND AL1.`upperboundexcluded` > AL3.`der_attr`;


