-- Group [Group]
create table `group` (
   `oid`  integer  not null,
   `groupname`  varchar(255),
  primary key (`oid`)
);


-- Module [Module]
create table `module` (
   `oid`  integer  not null,
   `moduleid`  varchar(255),
   `modulename`  varchar(255),
  primary key (`oid`)
);


-- User [User]
create table `user` (
   `oid`  integer  not null,
   `username`  varchar(255),
   `password`  varchar(255),
   `email`  varchar(255),
   `name`  varchar(255),
   `surname`  varchar(255),
   `address`  varchar(255),
   `age`  integer,
   `weight`  integer,
  primary key (`oid`)
);


-- KartingCenter [ent1]
create table `kartingcenter` (
   `oid`  integer  not null,
   `name`  varchar(255),
  primary key (`oid`)
);


-- Organizer [ent10]
create table `organizer` (
   `user_oid`  integer  not null,
  primary key (`user_oid`)
);


-- EventCategory [ent11]
create table `eventcategory` (
   `oid`  integer  not null,
   `pilotcategory`  varchar(255),
  primary key (`oid`)
);


-- Pilot [ent12]
create table `pilot` (
   `user_oid`  integer  not null,
  primary key (`user_oid`)
);


-- City [ent15]
create table `city` (
   `oid`  integer  not null,
   `name`  varchar(255),
  primary key (`oid`)
);


-- PopularTrack [ent16]
create table `populartrack` (
   `track_oid`  integer  not null,
  primary key (`track_oid`)
);


-- LeaderBoard [ent17]
create table `leaderboard` (
   `oid`  integer  not null,
  primary key (`oid`)
);


-- Timetable [ent18]
create table `timetable` (
   `oid`  integer  not null,
  primary key (`oid`)
);


-- Track [ent2]
create table `track` (
   `oid`  integer  not null,
   `name`  varchar(255),
   `length`  integer,
  primary key (`oid`)
);


-- TrackLengthRange [ent20]
create table `tracklengthrange` (
   `oid`  integer  not null,
   `lowerboundincluded`  integer,
   `upperboundexcluded`  integer,
  primary key (`oid`)
);


-- PriceRange [ent21]
create table `pricerange` (
   `oid`  integer  not null,
   `lowerboundincluded`  decimal(19,2),
   `upperboundexcluded`  decimal(19,2),
  primary key (`oid`)
);


-- Reservation [ent22]
create table `reservation` (
   `oid`  integer  not null,
   `start`  time,
   `end`  time,
   `date`  date,
  primary key (`oid`)
);


-- EventReview [ent23]
create table `eventreview` (
   `review_oid`  integer  not null,
  primary key (`review_oid`)
);


-- KartingCenterReview [ent24]
create table `kartingcenterreview` (
   `review_oid`  integer  not null,
  primary key (`review_oid`)
);


-- TrackDifficulty [ent25]
create table `trackdifficulty` (
   `oid`  integer  not null,
   `difficulty`  varchar(255),
  primary key (`oid`)
);


-- TrackAsphalt [ent26]
create table `trackasphalt` (
   `oid`  integer  not null,
   `asphalttype`  varchar(255),
  primary key (`oid`)
);


-- NEventsRange [ent27]
create table `neventsrange` (
   `oid`  integer  not null,
   `lowerboundincluded`  integer,
   `upperboundexcluded`  integer,
  primary key (`oid`)
);


-- NRacesRange [ent28]
create table `nracesrange` (
   `oid`  integer  not null,
   `lowerboundincluded`  integer,
   `upperboundexcluded`  integer,
  primary key (`oid`)
);


-- NPilotsRange [ent29]
create table `npilotsrange` (
   `oid`  integer  not null,
   `lowerboundincluded`  integer,
   `upperboundexcluded`  integer,
  primary key (`oid`)
);


-- KartingCenterAdmin [ent3]
create table `kartingcenteradmin` (
   `user_oid`  integer  not null,
  primary key (`user_oid`)
);


-- Clerk [ent30]
create table `clerk` (
   `user_oid`  integer  not null,
  primary key (`user_oid`)
);


-- EReviewScoreRange [ent31]
create table `ereviewscorerange` (
   `oid`  integer  not null,
   `lowerboundincluded`  double precision,
   `upperboundexcluded`  double precision,
  primary key (`oid`)
);


-- TrackReview [ent32]
create table `trackreview` (
   `review_oid`  integer  not null,
  primary key (`review_oid`)
);


-- TReviewScoreRange [ent33]
create table `treviewscorerange` (
   `oid`  integer  not null,
   `lowerboundincluded`  double precision,
   `upperboundexcluded`  double precision,
  primary key (`oid`)
);


-- Application [ent34]
create table `application` (
   `oid`  integer  not null,
   `confirmed`  bit,
  primary key (`oid`)
);


-- Review [ent35]
create table `review` (
   `oid`  integer  not null,
   `textreview`  longtext,
   `score`  integer,
   `reviewtype`  varchar(255),
  primary key (`oid`)
);


-- Administrator [ent37]
create table `administrator` (
   `user_oid`  integer  not null,
  primary key (`user_oid`)
);


-- KCReviewScoreRange [ent4]
create table `kcreviewscorerange` (
   `oid`  integer  not null,
   `lowerboundincluded`  double precision,
   `upperboundexcluded`  double precision,
  primary key (`oid`)
);


-- GoKart [ent5]
create table `gokart` (
   `oid`  integer  not null,
  primary key (`oid`)
);


-- GoKartModel [ent6]
create table `gokartmodel` (
   `oid`  integer  not null,
   `gokartmodel`  varchar(255),
  primary key (`oid`)
);


-- Race [ent7]
create table `race` (
   `oid`  integer  not null,
   `date`  date,
   `start`  time,
   `end`  time,
   `forevent`  bit,
  primary key (`oid`)
);


-- LapTime [ent8]
create table `laptime` (
   `oid`  integer  not null,
   `lapnumber`  integer,
   `laptime`  decimal(19,2),
  primary key (`oid`)
);


-- Event [ent9]
create table `event` (
   `oid`  integer  not null,
   `name`  varchar(255),
   `price`  decimal(19,2),
  primary key (`oid`)
);


-- Group_DefaultModule [Group2DefaultModule_DefaultModule2Group]
alter table `group`  add column  `module_oid`  integer;
alter table `group`   add index fk_group_module (`module_oid`), add constraint fk_group_module foreign key (`module_oid`) references `module` (`oid`);


-- Group_Module [Group2Module_Module2Group]
create table `group_module` (
   `group_oid`  integer not null,
   `module_oid`  integer not null,
  primary key (`group_oid`, `module_oid`)
);
alter table `group_module`   add index fk_group_module_group (`group_oid`), add constraint fk_group_module_group foreign key (`group_oid`) references `group` (`oid`);
alter table `group_module`   add index fk_group_module_module (`module_oid`), add constraint fk_group_module_module foreign key (`module_oid`) references `module` (`oid`);


-- User_DefaultGroup [User2DefaultGroup_DefaultGroup2User]
alter table `user`  add column  `group_oid`  integer;
alter table `user`   add index fk_user_group (`group_oid`), add constraint fk_user_group foreign key (`group_oid`) references `group` (`oid`);


-- User_Group [User2Group_Group2User]
create table `user_group` (
   `user_oid`  integer not null,
   `group_oid`  integer not null,
  primary key (`user_oid`, `group_oid`)
);
alter table `user_group`   add index fk_user_group_user (`user_oid`), add constraint fk_user_group_user foreign key (`user_oid`) references `user` (`oid`);
alter table `user_group`   add index fk_user_group_group (`group_oid`), add constraint fk_user_group_group foreign key (`group_oid`) references `group` (`oid`);


-- KartingCenter_Track [rel1]
alter table `track`  add column  `kartingcenter_oid`  integer;
alter table `track`   add index fk_track_kartingcenter (`kartingcenter_oid`), add constraint fk_track_kartingcenter foreign key (`kartingcenter_oid`) references `kartingcenter` (`oid`);


-- EventCategory_Event [rel10]
alter table `event`  add column  `eventcategory_oid`  integer;
alter table `event`   add index fk_event_eventcategory (`eventcategory_oid`), add constraint fk_event_eventcategory foreign key (`eventcategory_oid`) references `eventcategory` (`oid`);


-- Participation [rel11]
create table `participation` (
   `pilot_oid`  integer not null,
   `race_oid`  integer not null,
  primary key (`pilot_oid`, `race_oid`)
);
alter table `participation`   add index fk_participation_pilot (`pilot_oid`), add constraint fk_participation_pilot foreign key (`pilot_oid`) references `pilot` (`user_oid`);
alter table `participation`   add index fk_participation_race (`race_oid`), add constraint fk_participation_race foreign key (`race_oid`) references `race` (`oid`);


-- City_KartingCenter [rel12]
alter table `kartingcenter`  add column  `city_oid`  integer;
alter table `kartingcenter`   add index fk_kartingcenter_city (`city_oid`), add constraint fk_kartingcenter_city foreign key (`city_oid`) references `city` (`oid`);


-- LeaderBoard_Track [rel13]
alter table `leaderboard`  add column  `track_oid`  integer;
alter table `leaderboard`   add index fk_leaderboard_track (`track_oid`), add constraint fk_leaderboard_track foreign key (`track_oid`) references `track` (`oid`);


-- Timetable_Track [rel14]
alter table `track`  add column  `timetable_oid`  integer;
alter table `track`   add index fk_track_timetable (`timetable_oid`), add constraint fk_track_timetable foreign key (`timetable_oid`) references `timetable` (`oid`);


-- Event_Race [rel2]
alter table `race`  add column  `event_oid`  integer;
alter table `race`   add index fk_race_event (`event_oid`), add constraint fk_race_event foreign key (`event_oid`) references `event` (`oid`);


-- GoKartCategory_Track [rel20]
create table `gokartcategory_track` (
   `gokartmodel_oid`  integer not null,
   `track_oid`  integer not null,
  primary key (`gokartmodel_oid`, `track_oid`)
);
alter table `gokartcategory_track`   add index fk_gokartcategory_track_gokart (`gokartmodel_oid`), add constraint fk_gokartcategory_track_gokart foreign key (`gokartmodel_oid`) references `gokartmodel` (`oid`);
alter table `gokartcategory_track`   add index fk_gokartcategory_track_track (`track_oid`), add constraint fk_gokartcategory_track_track foreign key (`track_oid`) references `track` (`oid`);


-- Pilot_Reservation [rel21]
alter table `reservation`  add column  `pilot_oid`  integer;
alter table `reservation`   add index fk_reservation_pilot (`pilot_oid`), add constraint fk_reservation_pilot foreign key (`pilot_oid`) references `pilot` (`user_oid`);


-- Reservation_Race [rel22]
alter table `race`  add column  `reservation_oid`  integer;
alter table `race`   add index fk_race_reservation (`reservation_oid`), add constraint fk_race_reservation foreign key (`reservation_oid`) references `reservation` (`oid`);


-- TrackDifficulty_Track [rel23]
alter table `track`  add column  `trackdifficulty_oid`  integer;
alter table `track`   add index fk_track_trackdifficulty (`trackdifficulty_oid`), add constraint fk_track_trackdifficulty foreign key (`trackdifficulty_oid`) references `trackdifficulty` (`oid`);


-- Race_LapTime [rel24]
alter table `laptime`  add column  `race_oid`  integer;
alter table `laptime`   add index fk_laptime_race (`race_oid`), add constraint fk_laptime_race foreign key (`race_oid`) references `race` (`oid`);


-- EventReview_Pilot [rel25]
alter table `eventreview`  add column  `pilot_oid`  integer;
alter table `eventreview`   add index fk_eventreview_pilot (`pilot_oid`), add constraint fk_eventreview_pilot foreign key (`pilot_oid`) references `pilot` (`user_oid`);


-- EventReview_Event [rel26]
alter table `eventreview`  add column  `event_oid`  integer;
alter table `eventreview`   add index fk_eventreview_event (`event_oid`), add constraint fk_eventreview_event foreign key (`event_oid`) references `event` (`oid`);


-- LapTime_Pilot [rel27]
alter table `laptime`  add column  `pilot_oid`  integer;
alter table `laptime`   add index fk_laptime_pilot (`pilot_oid`), add constraint fk_laptime_pilot foreign key (`pilot_oid`) references `pilot` (`user_oid`);


-- KartingCenterReview_KartingCenter [rel28]
alter table `kartingcenterreview`  add column  `kartingcenter_oid`  integer;
alter table `kartingcenterreview`   add index fk_kartingcenterreview_karting (`kartingcenter_oid`), add constraint fk_kartingcenterreview_karting foreign key (`kartingcenter_oid`) references `kartingcenter` (`oid`);


-- Pilot_KartingCenterReview [rel29]
alter table `kartingcenterreview`  add column  `pilot_oid`  integer;
alter table `kartingcenterreview`   add index fk_kartingcenterreview_pilot (`pilot_oid`), add constraint fk_kartingcenterreview_pilot foreign key (`pilot_oid`) references `pilot` (`user_oid`);


-- Organizer_Event [rel3]
alter table `event`  add column  `organizer_oid`  integer;
alter table `event`   add index fk_event_organizer (`organizer_oid`), add constraint fk_event_organizer foreign key (`organizer_oid`) references `organizer` (`user_oid`);


-- TrackAsphalt_Track [rel30]
alter table `track`  add column  `trackasphalt_oid`  integer;
alter table `track`   add index fk_track_trackasphalt (`trackasphalt_oid`), add constraint fk_track_trackasphalt foreign key (`trackasphalt_oid`) references `trackasphalt` (`oid`);


-- Organizer_Reservation [rel34]
alter table `reservation`  add column  `organizer_oid`  integer;
alter table `reservation`   add index fk_reservation_organizer (`organizer_oid`), add constraint fk_reservation_organizer foreign key (`organizer_oid`) references `organizer` (`user_oid`);


-- Clerk_KartingCenter [rel35]
alter table `clerk`  add column  `kartingcenter_oid`  integer;
alter table `clerk`   add index fk_clerk_kartingcenter (`kartingcenter_oid`), add constraint fk_clerk_kartingcenter foreign key (`kartingcenter_oid`) references `kartingcenter` (`oid`);


-- Clerk_Reservation [rel36]
alter table `reservation`  add column  `clerk_oid`  integer;
alter table `reservation`   add index fk_reservation_clerk (`clerk_oid`), add constraint fk_reservation_clerk foreign key (`clerk_oid`) references `clerk` (`user_oid`);


-- KartingCenterAdmin_KartingCenter [rel4]
alter table `kartingcenter`  add column  `kartingcenteradmin_oid`  integer;
alter table `kartingcenter`   add index fk_kartingcenter_kartingcenter (`kartingcenteradmin_oid`), add constraint fk_kartingcenter_kartingcenter foreign key (`kartingcenteradmin_oid`) references `kartingcenteradmin` (`user_oid`);


-- City_Track [rel43]
alter table `track`  add column  `city_oid`  integer;
alter table `track`   add index fk_track_city (`city_oid`), add constraint fk_track_city foreign key (`city_oid`) references `city` (`oid`);


-- City_Event [rel44]
create table `city_event` (
   `city_oid`  integer not null,
   `event_oid`  integer not null,
  primary key (`city_oid`, `event_oid`)
);
alter table `city_event`   add index fk_city_event_city (`city_oid`), add constraint fk_city_event_city foreign key (`city_oid`) references `city` (`oid`);
alter table `city_event`   add index fk_city_event_event (`event_oid`), add constraint fk_city_event_event foreign key (`event_oid`) references `event` (`oid`);


-- TrackReview_Pilot [rel45]
alter table `trackreview`  add column  `pilot_oid`  integer;
alter table `trackreview`   add index fk_trackreview_pilot (`pilot_oid`), add constraint fk_trackreview_pilot foreign key (`pilot_oid`) references `pilot` (`user_oid`);


-- TrackReview_Track [rel46]
alter table `trackreview`  add column  `track_oid`  integer;
alter table `trackreview`   add index fk_trackreview_track (`track_oid`), add constraint fk_trackreview_track foreign key (`track_oid`) references `track` (`oid`);


-- Pilot_Application [rel48]
alter table `application`  add column  `pilot_oid`  integer;
alter table `application`   add index fk_application_pilot (`pilot_oid`), add constraint fk_application_pilot foreign key (`pilot_oid`) references `pilot` (`user_oid`);


-- Application_Event [rel49]
alter table `application`  add column  `event_oid`  integer;
alter table `application`   add index fk_application_event (`event_oid`), add constraint fk_application_event foreign key (`event_oid`) references `event` (`oid`);


-- Timetable_Reservation [rel5]
alter table `reservation`  add column  `timetable_oid`  integer;
alter table `reservation`   add index fk_reservation_timetable (`timetable_oid`), add constraint fk_reservation_timetable foreign key (`timetable_oid`) references `timetable` (`oid`);


-- FavouriteTracks [rel50]
create table `favouritetracks` (
   `pilot_oid`  integer not null,
   `track_oid`  integer not null,
  primary key (`pilot_oid`, `track_oid`)
);
alter table `favouritetracks`   add index fk_favouritetracks_pilot (`pilot_oid`), add constraint fk_favouritetracks_pilot foreign key (`pilot_oid`) references `pilot` (`user_oid`);
alter table `favouritetracks`   add index fk_favouritetracks_track (`track_oid`), add constraint fk_favouritetracks_track foreign key (`track_oid`) references `track` (`oid`);


-- LastRace [rel51]
alter table `pilot`  add column  `race_oid`  integer;
alter table `pilot`   add index fk_pilot_race (`race_oid`), add constraint fk_pilot_race foreign key (`race_oid`) references `race` (`oid`);


-- GoKart_Track [rel6]
alter table `gokart`  add column  `track_oid`  integer;
alter table `gokart`   add index fk_gokart_track (`track_oid`), add constraint fk_gokart_track foreign key (`track_oid`) references `track` (`oid`);


-- GoKartCategory_GoKart [rel7]
alter table `gokart`  add column  `gokartmodel_oid`  integer;
alter table `gokart`   add index fk_gokart_gokartmodel (`gokartmodel_oid`), add constraint fk_gokart_gokartmodel foreign key (`gokartmodel_oid`) references `gokartmodel` (`oid`);


-- Race_Track [rel8]
alter table `race`  add column  `track_oid`  integer;
alter table `race`   add index fk_race_track (`track_oid`), add constraint fk_race_track foreign key (`track_oid`) references `track` (`oid`);


-- GEN FK: Organizer --> User
alter table `organizer`   add index fk_organizer_user (`user_oid`), add constraint fk_organizer_user foreign key (`user_oid`) references `user` (`oid`);


-- GEN FK: Pilot --> User
alter table `pilot`   add index fk_pilot_user (`user_oid`), add constraint fk_pilot_user foreign key (`user_oid`) references `user` (`oid`);


-- GEN FK: PopularTrack --> Track
alter table `populartrack`   add index fk_populartrack_track (`track_oid`), add constraint fk_populartrack_track foreign key (`track_oid`) references `track` (`oid`);


-- GEN FK: EventReview --> Review
alter table `eventreview`   add index fk_eventreview_review (`review_oid`), add constraint fk_eventreview_review foreign key (`review_oid`) references `review` (`oid`);


-- GEN FK: KartingCenterReview --> Review
alter table `kartingcenterreview`   add index fk_kartingcenterreview_review (`review_oid`), add constraint fk_kartingcenterreview_review foreign key (`review_oid`) references `review` (`oid`);


-- GEN FK: Clerk --> User
alter table `clerk`   add index fk_clerk_user (`user_oid`), add constraint fk_clerk_user foreign key (`user_oid`) references `user` (`oid`);


-- GEN FK: TrackReview --> Review
alter table `trackreview`   add index fk_trackreview_review (`review_oid`), add constraint fk_trackreview_review foreign key (`review_oid`) references `review` (`oid`);


-- GEN FK: Administrator --> User
alter table `administrator`   add index fk_administrator_user (`user_oid`), add constraint fk_administrator_user foreign key (`user_oid`) references `user` (`oid`);


-- GEN FK: KartingCenterAdmin --> User
alter table `kartingcenteradmin`   add index fk_kartingcenteradmin_user (`user_oid`), add constraint fk_kartingcenteradmin_user foreign key (`user_oid`) references `user` (`oid`);


-- KartingCenter.avgReviewScore [ent1#att32]
create view `kartingcenter_avgreviewscore_v` as
select AL1.`oid` as `oid`, avg(AL3.`score`) as `der_attr`
from  `kartingcenter` AL1 
               left outer join `kartingcenterreview` AL2 on AL1.`oid`=AL2.`kartingcenter_oid`
               left outer join `review` AL3 on AL2.`review_oid`=AL3.`oid`
group by AL1.`oid`;


-- Track.avgReviewScore [ent2#att109]
create view `track_avgreviewscore_view` as
select AL1.`oid` as `oid`, avg(AL3.`score`) as `der_attr`
from  `track` AL1 
               left outer join `trackreview` AL2 on AL1.`oid`=AL2.`track_oid`
               left outer join `review` AL3 on AL2.`review_oid`=AL3.`oid`
group by AL1.`oid`;


-- Track.nRentalGoKarts [ent2#att70]
create view `track_nrentalgokarts_view` as
select AL1.`oid` as `oid`, count(distinct AL2.`oid`) as `der_attr`
from  `track` AL1 
               left outer join `gokart` AL2 on AL1.`oid`=AL2.`track_oid`
group by AL1.`oid`;


-- Track.nRaces [ent2#att75]
create view `track_nraces_view` as
select AL1.`oid` as `oid`, count(distinct AL2.`oid`) as `der_attr`
from  `track` AL1 
               left outer join `race` AL2 on AL1.`oid`=AL2.`track_oid`
group by AL1.`oid`;


-- KartingCenter.nRaces [ent1#att77]
create view `kartingcenter_nraces_view` as
select AL1.`oid` as `oid`, sum(AL3.`der_attr`) as `der_attr`
from  `kartingcenter` AL1 
               left outer join `track` AL2 on AL1.`oid`=AL2.`kartingcenter_oid`
               left outer join `track_nraces_view` AL3 on AL2.`oid`=AL3.`oid`
group by AL1.`oid`;


-- Track.nEvents [ent2#att76]
create view `track_nevents_view` as
select AL1.`oid` as `oid`, count(distinct AL2.`event_oid`) as `der_attr`
from  `track` AL1 
               left outer join `race` AL2 on AL1.`oid`=AL2.`track_oid`
group by AL1.`oid`;


-- KartingCenter.nEvents [ent1#att79]
create view `kartingcenter_nevents_view` as
select AL1.`oid` as `oid`, sum(AL3.`der_attr`) as `der_attr`
from  `kartingcenter` AL1 
               left outer join `track` AL2 on AL1.`oid`=AL2.`kartingcenter_oid`
               left outer join `track_nevents_view` AL3 on AL2.`oid`=AL3.`oid`
group by AL1.`oid`;


-- Race.nPartecipants [ent7#att39]
create view `race_npartecipants_view` as
select AL1.`oid` as `oid`, count(distinct AL2.`pilot_oid`) as `der_attr`
from  `race` AL1 
               left outer join `participation` AL2 on AL1.`oid`=AL2.`race_oid`
group by AL1.`oid`;


-- Track.nPilots [ent2#att80]
create view `track_npilots_view` as
select AL1.`oid` as `oid`, sum(AL3.`der_attr`) as `der_attr`
from  `track` AL1 
               left outer join `race` AL2 on AL1.`oid`=AL2.`track_oid`
               left outer join `race_npartecipants_view` AL3 on AL2.`oid`=AL3.`oid`
group by AL1.`oid`;


-- KartingCenter.nPilots [ent1#att78]
create view `kartingcenter_npilots_view` as
select AL1.`oid` as `oid`, sum(AL3.`der_attr`) as `der_attr`
from  `kartingcenter` AL1 
               left outer join `track` AL2 on AL1.`oid`=AL2.`kartingcenter_oid`
               left outer join `track_npilots_view` AL3 on AL2.`oid`=AL3.`oid`
group by AL1.`oid`;


-- Race.fastestLapTime [ent7#att94]
create view `race_fastestlaptime_view` as
select AL1.`oid` as `oid`, min(AL2.`laptime`) as `der_attr`
from  `race` AL1 
               left outer join `laptime` AL2 on AL1.`oid`=AL2.`race_oid`
group by AL1.`oid`;


-- Event.FirstDate [ent9#att114]
create view `event_firstdate_view` as
select AL1.`oid` as `oid`, min(AL2.`date`) as `der_attr`
from  `event` AL1 
               left outer join `race` AL2 on AL1.`oid`=AL2.`event_oid`
group by AL1.`oid`;


-- UpcomingEvent [ent13]
create view `upcomingevent_view` as
select distinct AL1.`oid` as `oid`
from  `event` AL1 
               left outer join `event_firstdate_view` AL2 on AL1.`oid`=AL2.`oid`
group by AL1.`oid`, AL2.`der_attr`
having AL2.`der_attr` >= max(AL2.`der_attr`);


-- Event.nRaces [ent9#att43]
create view `event_nraces_view` as
select AL1.`oid` as `oid`, count(distinct AL2.`oid`) as `der_attr`
from  `event` AL1 
               left outer join `race` AL2 on AL1.`oid`=AL2.`event_oid`
group by AL1.`oid`;


-- Event.nReviews [ent9#att48]
create view `event_nreviews_view` as
select AL1.`oid` as `oid`, count(distinct AL2.`review_oid`) as `der_attr`
from  `event` AL1 
               left outer join `eventreview` AL2 on AL1.`oid`=AL2.`event_oid`
group by AL1.`oid`;


-- Event.maxReviewScore [ent9#att49]
create view `event_maxreviewscore_view` as
select AL1.`oid` as `oid`, max(AL3.`score`) as `der_attr`
from  `event` AL1 
               left outer join `eventreview` AL2 on AL1.`oid`=AL2.`event_oid`
               left outer join `review` AL3 on AL2.`review_oid`=AL3.`oid`
group by AL1.`oid`;


-- Event.minReviewScore [ent9#att50]
create view `event_minreviewscore_view` as
select AL1.`oid` as `oid`, min(AL3.`score`) as `der_attr`
from  `event` AL1 
               left outer join `eventreview` AL2 on AL1.`oid`=AL2.`event_oid`
               left outer join `review` AL3 on AL2.`review_oid`=AL3.`oid`
group by AL1.`oid`;


-- Event.avgReviewScore [ent9#att51]
create view `event_avgreviewscore_view` as
select AL1.`oid` as `oid`, avg(AL3.`score`) as `der_attr`
from  `event` AL1 
               left outer join `eventreview` AL2 on AL1.`oid`=AL2.`event_oid`
               left outer join `review` AL3 on AL2.`review_oid`=AL3.`oid`
group by AL1.`oid`;


-- ControversialEvent [ent19]
create view `controversialevent_view` as
select distinct AL1.`oid` as `oid`
from  `event` AL1 
               left outer join `event_avgreviewscore_view` AL2 on AL1.`oid`=AL2.`oid`
               left outer join `event_minreviewscore_view` AL3 on AL1.`oid`=AL3.`oid`
               left outer join `event_maxreviewscore_view` AL4 on AL1.`oid`=AL4.`oid`
where AL2.`der_attr` >= 4 AND AL2.`der_attr` <= 6 AND AL3.`der_attr` < 3 AND AL4.`der_attr` > 7;


-- EventConfirmed4Pilot [rel15]
create view `eventconfirmed4pilot_view` as
select distinct AL1.`oid` as `s_oid`, AL2.`pilot_oid` as `T_pilot_oid`
from  `event` AL1 
               left outer join `application` AL2 on AL1.`oid`=AL2.`event_oid`
where AL2.`confirmed` = '1';


-- Event.nPartecipants [ent9#att38]
create view `event_npartecipants_view` as
select AL1.`oid` as `oid`, count(distinct AL2.`T_pilot_oid`) as `der_attr`
from  `event` AL1 
               left outer join `eventconfirmed4pilot_view` AL2 on AL1.`oid`=AL2.`s_oid`
group by AL1.`oid`;


-- PopularEvent [ent14]
create view `popularevent_view` as
select distinct AL1.`oid` as `oid`
from  `event` AL1 
               left outer join `event_npartecipants_view` AL2 on AL1.`oid`=AL2.`oid`
               left outer join `event_nreviews_view` AL3 on AL1.`oid`=AL3.`oid`
where AL2.`der_attr` >= 10 AND AL3.`der_attr` >= 10;


-- Track_TrackLength [rel18]
create view `tracktotracklength_view` as
select AL1.`oid` as `s_oid`, AL2.`oid` as `t_oid`
from  `track` AL1 ,
         `tracklengthrange` AL2 
where AL1.`length` >= AL2.`lowerboundincluded` AND AL1.`length` < AL2.`upperboundexcluded`;


-- PriceRange_Event [rel19]
create view `pricerangetoevent_view` as
select AL1.`oid` as `s_oid`, AL2.`oid` as `t_oid`
from  `pricerange` AL1 ,
         `event` AL2 
where AL1.`lowerboundincluded` <= AL2.`price` AND AL1.`upperboundexcluded` > AL2.`price`;


-- NEventsRange_KartingCenter [rel31]
create view `neventsrangetokartingcenter_vi` as
select AL1.`oid` as `s_oid`, AL2.`oid` as `t_oid`
from  `neventsrange` AL1 ,
         `kartingcenter` AL2 
               left outer join `kartingcenter_nevents_view` AL3 on AL2.`oid`=AL3.`oid`
where AL1.`lowerboundincluded` <= AL3.`der_attr` AND AL1.`upperboundexcluded` > AL3.`der_attr`;


-- NRacesRange_KartingCenter [rel32]
create view `nracesrangetokartingcenter_vie` as
select AL1.`oid` as `s_oid`, AL2.`oid` as `t_oid`
from  `nracesrange` AL1 ,
         `kartingcenter` AL2 
               left outer join `kartingcenter_nraces_view` AL3 on AL2.`oid`=AL3.`oid`
where AL1.`lowerboundincluded` <= AL3.`der_attr` AND AL1.`upperboundexcluded` > AL3.`der_attr`;


-- NPilotsRange_KartingCenter [rel33]
create view `npilotsrangetokartingcenter_vi` as
select AL1.`oid` as `s_oid`, AL2.`oid` as `t_oid`
from  `npilotsrange` AL1 ,
         `kartingcenter` AL2 
               left outer join `kartingcenter_npilots_view` AL3 on AL2.`oid`=AL3.`oid`
where AL1.`lowerboundincluded` <= AL3.`der_attr` AND AL1.`upperboundexcluded` > AL3.`der_attr`;


-- LeaderBoard_LapTime [rel37]
create view `leaderboardtolaptime_view` as
select distinct AL1.`oid` as `s_oid`, AL3.`oid` as `T_oid`
from  `leaderboard` AL1 
               left outer join `race` AL2 on AL1.`track_oid`=AL2.`track_oid`
               left outer join `laptime` AL3 on AL2.`oid`=AL3.`race_oid`
group by AL1.`oid`, AL3.`oid`, AL3.`laptime`
having AL3.`laptime` <= avg(AL3.`laptime`);


-- KCReviewScoreRange_KartingCenter [rel38]
create view `kcreviewscorerangetokartingcen` as
select AL1.`oid` as `s_oid`, AL2.`oid` as `t_oid`
from  `kcreviewscorerange` AL1 ,
         `kartingcenter` AL2 
               left outer join `kartingcenter_avgreviewscore_v` AL3 on AL2.`oid`=AL3.`oid`
where AL1.`lowerboundincluded` <= AL3.`der_attr` AND AL1.`upperboundexcluded` > AL3.`der_attr`;


-- EReviewScoreRange_Event [rel39]
create view `ereviewscorerangetoevent_view` as
select AL1.`oid` as `s_oid`, AL2.`oid` as `t_oid`
from  `ereviewscorerange` AL1 ,
         `event` AL2 
               left outer join `event_avgreviewscore_view` AL3 on AL2.`oid`=AL3.`oid`
where AL1.`lowerboundincluded` <= AL3.`der_attr` AND AL1.`upperboundexcluded` > AL3.`der_attr`;


-- NPilotsRange_Track [rel40]
create view `npilotsrangetotrack_view` as
select AL1.`oid` as `s_oid`, AL2.`oid` as `t_oid`
from  `npilotsrange` AL1 ,
         `track` AL2 
               left outer join `track_npilots_view` AL3 on AL2.`oid`=AL3.`oid`
where AL1.`lowerboundincluded` <= AL3.`der_attr` AND AL1.`upperboundexcluded` > AL3.`der_attr`;


-- NEventsRange_Track [rel41]
create view `neventsrangetotrack_view` as
select AL1.`oid` as `s_oid`, AL2.`oid` as `t_oid`
from  `neventsrange` AL1 ,
         `track` AL2 
               left outer join `track_nevents_view` AL3 on AL2.`oid`=AL3.`oid`
where AL1.`lowerboundincluded` <= AL3.`der_attr` AND AL1.`upperboundexcluded` > AL3.`der_attr`;


-- NRacesRange_Track [rel42]
create view `nracesrangetotrack_view` as
select AL1.`oid` as `s_oid`, AL2.`oid` as `t_oid`
from  `nracesrange` AL1 ,
         `track` AL2 
               left outer join `track_nraces_view` AL3 on AL2.`oid`=AL3.`oid`
where AL1.`lowerboundincluded` <= AL3.`der_attr` AND AL1.`upperboundexcluded` > AL3.`der_attr`;


-- TReviewScoreRange_Track [rel47]
create view `treviewscorerangetotrack_view` as
select AL1.`oid` as `s_oid`, AL2.`oid` as `t_oid`
from  `treviewscorerange` AL1 ,
         `track` AL2 
               left outer join `track_avgreviewscore_view` AL3 on AL2.`oid`=AL3.`oid`
where AL1.`lowerboundincluded` <= AL3.`der_attr` AND AL1.`upperboundexcluded` > AL3.`der_attr`;


-- Event_KartingCenter [rel52]
create view `eventtokartingcenter_view` as
select distinct AL1.`oid` as `s_oid`, AL3.`kartingcenter_oid` as `T_kartingcenter_oid`
from  `event` AL1 
               inner join `race` AL2 on AL1.`oid`=AL2.`event_oid`
               inner join `track` AL3 on AL2.`track_oid`=AL3.`oid`;


-- Event_Track [rel53]
create view `eventtotrack_view` as
select distinct AL1.`oid` as `s_oid`, AL2.`track_oid` as `T_track_oid`
from  `event` AL1 
               inner join `race` AL2 on AL1.`oid`=AL2.`event_oid`;


