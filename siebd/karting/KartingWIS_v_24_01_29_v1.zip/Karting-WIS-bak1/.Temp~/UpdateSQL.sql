-- FastestLapTime [rel9]
create view `racetofastlap_view` as
select AL1.`oid` as `s_oid`, AL2.`oid` as `t_oid`
from  `laptime` AL2 ,
         `race` AL1 
               left outer join `race_fastestlaptime_view` AL3 on AL1.`oid`=AL3.`oid`
where AL3.`der_attr` = AL2.`laptime`;


