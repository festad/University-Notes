-- LeaderBoard_LapTime [rel37]
create table `leaderboard_laptime` (
   `leaderboard_2_oid`  integer not null,
   `laptime_2_oid`  integer not null,
  primary key (`leaderboard_2_oid`, `laptime_2_oid`)
);
alter table `leaderboard_laptime`   add index fk_leaderboard_laptime_leaderb (`leaderboard_2_oid`), add constraint fk_leaderboard_laptime_leaderb foreign key (`leaderboard_2_oid`) references `leaderboard_2` (`oid`);
alter table `leaderboard_laptime`   add index fk_leaderboard_laptime_laptime (`laptime_2_oid`), add constraint fk_leaderboard_laptime_laptime foreign key (`laptime_2_oid`) references `laptime_2` (`oid`);


